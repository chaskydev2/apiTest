export default {
    api_url: import.meta.env.VITE_API_URL,
    session: {
      tokenName: "_tkn",
    },
  };
  