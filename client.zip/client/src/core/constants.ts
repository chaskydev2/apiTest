export const ANNOUNCEMENT_TYPES = {
  general: "General",
  important: "Importante",
  news: "Noticia"
} as const;