
export default function SignUp() {
  return (
    <>
    </>
  );
}
